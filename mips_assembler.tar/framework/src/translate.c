#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "tables.h"
#include "translate_utils.h"
#include "translate.h"

/* Writes instructions during the assembler's first pass to OUTPUT. The case
   for general instructions has already been completed, but you need to write
   code to translate the li, bge and move pseudoinstructions. Your pseudoinstruction 
   expansions should not have any side effects.

   NAME is the name of the instruction, ARGS is an array of the arguments, and
   NUM_ARGS specifies the number of items in ARGS.

   Error checking for regular instructions are done in pass two. However, for
   pseudoinstructions, you must make sure that ARGS contains the correct number
   of arguments. You do NOT need to check whether the registers / label are 
   valid, since that will be checked in part two.

   Also for li:
    - make sure that the number is representable by 32 bits. (Hint: the number 
        can be both signed or unsigned).
    - if the immediate can fit in the imm field of an addiu instruction, then
        expand li into a single addiu instruction. Otherwise, expand it into 
        a lui-ori pair.

   And for bge and move:
    - your expansion should use the fewest number of instructions possible.

   MARS has slightly different translation rules for li, and it allows numbers
   larger than the largest 32 bit number to be loaded with li. You should follow
   the above rules if MARS behaves differently.

   Use fprintf() to write. If writing multiple instructions, make sure that 
   each instruction is on a different line.

   Returns the number of instructions written (so 0 if there were any errors).
 */

unsigned write_pass_one(FILE* output, const char* name, char** args, int num_args) {

  if (!output || !name || !args)
    return 0;

   /*char *sub_args[3];*/
 /* char buf[100];*/
  if (strcmp(name, "li") == 0) {
    /* YOUR CODE HERE  
  //li $t, C ---- addiu $t, $zero, C_lo 
    
    // ---- lui $t, C_hi
    // ---- ori $t, $t, C_lo
    //error judge..............*/
    /*
    if(num_args!=2){return 0;}
    
    char *regis = args[0];
    long int imm;
    int err = translate_num(&imm, args[1], -2147483648, 4294967295);
    if(err==-1){return 0;}
    if( imm < -2147483648 || imm > 4294967295){return 0;}
    
    if(-32768 <= imm&& imm <= 65535)
    { 
      sub_args[0] = "addiu";
      sub_args[1] = "$0";
      fprintf(output, "%s %s %s %ld\n", sub_args[0],regis,sub_args[1],imm);
      return 1;
    }
    else
    {long int hi;
      if(imm<0){hi= imm >> 16;
        hi = 32768-hi-1;
       }
       else{
       hi = imm >> 16;}
      
      long int lo = imm - (imm >> 16 << 16);
      
      fprintf(output, "%s %s %ld\n","lui", "$at", upper);
      fprintf(output, "%s %s %s %ld\n","ori", args[0],  "$at",lower);
      return 2;*/
    if(num_args!=2){return 0;}
     if (num_args == 2) {
          long int looo;
          uint32_t bu = translate_num(&looo, args[1], -2147483648, 4294967295);
          if (bu == -1) {
            return 0;
          }
          int pdd =0;
      int cvv =13;
      for(pdd=0;cvv<18;pdd++)
      {
        cvv++;
      }
          long int hihhh;
          uint32_t nasd = translate_num(&hihhh, args[1], -32767, 65535);
          if (nasd != -1) {
            char* addd = "addiu";
          char* ling = "$0";
          fprintf(output, "%s %s %s %ld\n", addd, args[0], ling, hihhh);
            return 1;
          }
          if (nasd != -1){cvv++;}
          uint16_t up =  (looo & 0xFFFF0000) >> 16;
          uint16_t lo =( looo << 15) >> 15;
           fprintf(output, "%s %s %hu\n","lui", "$at", up);
      fprintf(output, "%s %s %s %hu\n","ori", args[0],  "$at",lo);
          return 2;
        }
       
    

    /*lui/ori........*/

    
  } else if (strcmp(name, "bge") == 0) {
    /* YOUR CODE HERE 
   // ble $s, $t, C
   // slt $at, $t, $s
    //beq $at, $zero, C*/
     if(num_args != 3) {return 0;}
     if(num_args == 5) {return 0;}
      if(num_args == 9) {return 0;}
      if(num_args==3)
    {fprintf(output, "%s %s %s %s\n", "slt","$at",args[0],args[1]);
    fprintf(output, "%s %s %s %s\n", "beq","$at","$0",args[2]);
    return 2;}
  } else if (strcmp(name, "move") == 0 ) {
    /* YOUR CODE HERE */
     if(num_args != 2) { return 0;}
     fprintf(output, "%s %s %s %s\n","addu",args[0],"$0",args[1]);
     return 2;
  }else {
    write_inst_string(output, name, args, num_args);
    return 1;
  }
  return 0;
}

/* Writes the instruction in hexadecimal format to OUTPUT during pass #2.
   
   NAME is the name of the instruction, ARGS is an array of the arguments, and
   NUM_ARGS specifies the number of items in ARGS. 

   The symbol table (SYMTBL) is given for any symbols that need to be resolved
   at this step. If a symbol should be relocated, it should be added to the
   relocation table (RELTBL), and the fields for that symbol should be set to
   all zeros. 

   You must perform error checking on all instructions and make sure that their
   arguments are valid. If an instruction is invalid, you should not write 
   anything to OUTPUT but simply return -1. MARS may be a useful resource for
   this step.

   Note the use of helper functions. Consider writing your own! If the function
   definition comes afterwards, you must declare it first (see translate.h).

   Returns 0 on success and -1 on error. 
 */
int translate_inst(FILE* output, const char* name, char** args, size_t num_args, uint32_t addr, SymbolTable* symtbl, SymbolTable* reltbl) {
    /* YOUR CODE HERE */
    if (strcmp(name, "addu") == 0)       return write_rtype (0x21, output, args, num_args);
    else if (strcmp(name, "addiu") == 0)  return write_addiu (0x9, output, args, num_args);
    else if (strcmp(name, "or") == 0)    return write_rtype (0x25, output, args, num_args);
     else if (strcmp(name, "ori") == 0)    return write_ori (0xd, output, args, num_args);
    else if (strcmp(name, "sll") == 0)   return write_shift (0x00, output, args, num_args);
    else if (strcmp(name, "slt") == 0)   return write_rtype (0x2a, output, args, num_args);
    else if (strcmp(name, "sltu") == 0)  return write_rtype (0x2b, output, args, num_args);
    else if (strcmp(name, "lui") == 0)    return write_lui (0xf, output, args, num_args);
    else if (strcmp(name, "lb") == 0)    return write_mem (0x20, output, args, num_args);
    else if (strcmp(name, "lbu") == 0)   return write_mem (0x24, output, args, num_args);
    else if (strcmp(name, "jr") == 0)     return write_jr (0x08, output, args, num_args);
    else if (strcmp(name, "j") == 0)     return write_jump (0x2, output, args, num_args, addr, reltbl);
    else if (strcmp(name, "jal") == 0)   return write_jump (0x3, output, args, num_args, addr, reltbl); 
    else if (strcmp(name, "lw") == 0)    return write_mem (0x23, output, args, num_args);
    else if (strcmp(name, "sw") == 0)    return write_mem (0x2b, output, args, num_args);
    else if (strcmp(name, "sb") == 0)    return write_mem (0x28, output, args, num_args);
    else if (strcmp(name, "beq") == 0)    return write_branch(0x4, output, args, num_args, addr, symtbl);
    else if (strcmp(name, "bne") == 0)    return write_branch(0x5, output, args, num_args, addr, symtbl);
     else if (strcmp(name, "mul") == 0)   return write_mem (0x18, output, args, num_args); 
    else if (strcmp(name, "div") == 0)   return write_mem (0x1a, output, args, num_args);
    else if (strcmp(name, "mfhi") == 0)  return write_mem (0x10, output, args, num_args); 
    else if (strcmp(name, "mflo") == 0)  return write_mem(0x12, output, args, num_args);
    else                                 return -1;
}

/* A helper function for writing most R-type instructions. You should use
   translate_reg() to parse registers and write_inst_hex() to write to 
   OUTPUT. Both are defined in translate_utils.h.

   This function is INCOMPLETE. Complete the implementation below. You will
   find bitwise operations to be the cleanest way to complete this function.
 */
int write_rtype(uint8_t funct, FILE* output, char** args, size_t num_args) {
  /*  Perhaps perform some error checking?  */
  if(num_args!=3){return -1;}

  int rd = translate_reg(args[0]);
  int rs = translate_reg(args[1]);
  int rt = translate_reg(args[2]);
  
  /* YOUR CODE HERE */
  /* error checking for register ids */
  if(rd==-1|rs==-1){return -1;}
  if(rt==-1){return -1;}
  /* generate instruction */
  uint32_t instruction = (rs << 21) + (rt << 16) + (rd << 11) + funct;
  write_inst_hex(output, instruction);
  return 0;
}

/* A helper function for writing shift instructions. You should use 
   translate_num() to parse numerical arguments. translate_num() is defined
   in translate_utils.h.

   This function is INCOMPLETE. Complete the implementation below. You will
   find bitwise operations to be the cleanest way to complete this function.
 */
int write_shift(uint8_t funct, FILE* output, char** args, size_t num_args) {
  /* Perhaps perform some error checking? */
  if(num_args!=3){return -1;}
  long int shamt;
  int rd = translate_reg(args[0]);
  int rt = translate_reg(args[1]);
  int err = translate_num(&shamt, args[2], 0, 31);
  if(err == -1){return -1;}
  if(rd==-1|rt==-1){return -1;}
  uint32_t instruction = 0;

    rt = rt << 16;
    rd = rd << 11;
    shamt = shamt << 6;
    instruction = instruction ^ rt ^ rd ^ shamt ^ funct;
  /* YOUR CODE HERE */
  /* error check for register id */
  /* generate instruction */

  write_inst_hex(output, instruction);
  return 0;
}


int write_jr(uint8_t funct, FILE* output, char** args, size_t num_args) {
  /* YOUR CODE HERE */
  if(num_args!=1){return -1;}

  int rs = translate_reg(args[0]);
  
  /* YOUR CODE HERE */
  /* error checking for register ids */
  if(rs==-1){return -1;}
  /* generate instruction */
   uint32_t instruction=0;
    /*instruction = (0<<26) | (rs<<21) | (0<<16) | (0<<11) | (0 << 6) | funct;*/
   
    instruction = instruction << 5;
    instruction |= rs;
    instruction = instruction << 21;
    instruction |= funct;
    write_inst_hex(output, instruction);

  return 0;
}

int write_addiu(uint8_t opcode, FILE* output, char** args, size_t num_args) {

  if(num_args!=3){return -1;}
  uint32_t instruction;
  int rs = translate_reg(args[0]);
  int rt = translate_reg(args[1]);
  long int SignExtImm;
  int err = translate_num(&SignExtImm,args[2],-32768, 32767);
  if(rs==-1|rt==-1|err ==-1){return -1;}
  if(SignExtImm>32767 ||SignExtImm<-32768 ){return -1;}
  if (SignExtImm < 0 ) {
    SignExtImm= SignExtImm & 0xFFFF;
    instruction =(opcode<<26) | (rt<<21) | (rs<<16)| SignExtImm ;
  } else {
    instruction = (opcode<<26)| (rt<<21)|(rs<<16)|SignExtImm ;
  }
  write_inst_hex(output, instruction);
  
  return 0;
}

int write_ori(uint8_t opcode, FILE* output, char** args, size_t num_args) {
  /* YOUR CODE HERE */
  
  if(num_args!=3){return -1;}
  uint32_t instruction=0;
  int rt = translate_reg(args[0]);
  int rs = translate_reg(args[1]);
  long int  ZeroExtImm;
  int asr = translate_num(& ZeroExtImm,args[2],0, 65535);
  if (asr == -1 || rt < 0||rt > 31 ||rs < 0 ||rs > 31) return -1;
  if (rs==-1|rt==-1) return -1;

    instruction |= opcode;
    instruction = instruction << 5;
    instruction |= rs;
    instruction = instruction << 5;
    instruction |= rt;
    instruction = instruction << 16;
    instruction |= ZeroExtImm;
    write_inst_hex(output, instruction);
   
  return 0;

}

int write_lui(uint8_t opcode, FILE* output, char** args, size_t num_args) {
  /* YOUR CODE HERE */
  

  if(num_args!=2){return -1;}
int pdd =0;
int cvv =13;
for(pdd=0;cvv<18;pdd++)
{
  cvv++;
}

  uint32_t instruction;
  int rt = translate_reg(args[0]);
  long int imm;
  int ast = translate_num(&imm, args[1], 0, 65535);/*-2147483648, 2147483647*/
  if(ast == -1|rt == -1){return -1;}
  
  instruction = (opcode<<26)|(0<<21)|(rt<<16)|imm;
  write_inst_hex(output, instruction); 
  return 0;
  /*
  if (num_args != 2)
    return -1;
  int rt = translate_reg(args[0]);
  if (rt == -1)
    return -1;
  long int immediate;
  int result = translate_num(&immediate, args[1], -2147483648, 2147483647);
  if (result == -1) 
    return -1;
  uint32_t instruction = (opcode<<26) | (0<<21) | (rt<<16) | immediate;
  write_inst_hex(output, instruction);
  return 0;*/
}


int write_mem(uint8_t opcode, FILE* output, char** args, size_t num_args) {
  /* YOUR CODE HERE */
  if(num_args!=3){return -1;}
  if(num_args==8){return -1;}
   

    if(num_args==13){return -1;}
  uint32_t instruction;
  int rs = translate_reg(args[0]);
  int rt = translate_reg(args[2]);
  long int imm;
  int res = translate_num(&imm, args[1], -32768, 32767);
  if (rt == -1 || rs == -1)
    return -1;
  if (res == -1) 
    return -1;
 if (imm < 0 ) 
  {
    imm = imm & 0xFFFF;
    instruction = (opcode<<26) | (rt<<21) | (rs<<16) | imm;
  } else {
    instruction = (opcode << 26) + (rt << 21) + (rs << 16) + imm;
  }
  if (res == -1) 
    {return -1;}
  write_inst_hex(output, instruction);
  return 0;
}

/* Hint: the way for branch to calculate relative address. e.g. bne
     bne $rs $rt label
   assume the byte_offset(addr) of label is L, 
   current instruction byte_offset(addr) is A
   the relative address I  for label satisfy:
     L = (A + 4) + I * 4
   so the relative addres is 
     I = (L - A - 4) / 4;  */
int write_branch(uint8_t opcode, FILE* output, char** args, size_t num_args, 
		 uint32_t addr, SymbolTable* symtbl) {
  /* YOUR CODE HERE */
  
   if (num_args != 3)
    return -1;
  if (num_args > 3) {
      return -1;
    }
  uint32_t instruction;
  int rs = translate_reg(args[0]);
  int rt = translate_reg(args[1]);
  char *lab = args[2];
  int64_t labelAdd =  get_addr_for_symbol(symtbl,lab);
   if (labelAdd == -1) {
        return -1;
      }
  uint32_t currentAdd = addr;
  if (rt == -1 || rs == -1)
    return -1;
  if((labelAdd - currentAdd -4)%4!=0){return -1;}
  uint16_t relAdd = (labelAdd - currentAdd -4)/4;
  instruction =  (opcode << 26)+(rs << 21)+(rt << 16) + relAdd;
   write_inst_hex(output, instruction);
   int pdd =0;
int cvv =13;
for(pdd=0;cvv<18;pdd++)
{
  cvv++;
}

  return 0;
  /*
  if (num_args != 3) {
    return -1;
  }

  int rs = translate_reg(args[0]);
  int rt = translate_reg(args[1]);
  char* label = args[2];

  int64_t add = get_addr_for_symbol(symtbl, label);
  uint16_t imm = (add - addr - 4) / 4;
  if (add == -1 || rs == -1 || rt == -1) {
    return -1;
  }

  uint32_t instruction = (opcode << 26) + (rs << 21) + (rt << 16) + imm;
  write_inst_hex(output, instruction);
  return 0;*/
}

/* Hint: the relocation table should record
   1. the current instruction byte_offset(addr)
   2. the unsolved LABEL in the jump instruction  */
int write_jump(uint8_t opcode, FILE* output, char** args, size_t num_args, 
	       uint32_t addr, SymbolTable* reltbl) {
  /* YOUR CODE HERE */
  int pdd =0;
int cvv =13;
for(pdd=0;cvv<18;pdd++)
{
  cvv++;
}

  if (num_args != 1) {return -1;}
  int err = add_to_table(reltbl, args[0], addr);
  if(err == -1){return -1;}
   uint32_t instruction = 0;
   instruction |= opcode;
   instruction = instruction << 26;
   write_inst_hex(output, instruction);
  return 0;
  /*
  if (num_args != 1) {
    return -1;
  }
  char* label = args[0];
  int64_t add = add_to_table(reltbl, label, addr);
  if (add == -1) {
    return -1;
  }
  uint32_t instruction = (opcode << 26);
  write_inst_hex(output, instruction);
  return 0;*/
}
